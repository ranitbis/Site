        // Game Variables
        let mines = [];
        let openedBoxes = [];
        let selectedMines = 0;
        let gameOver = false;
        let currentCoins = 0;
        let totalCoins = 0;
        let scartinoScore = 0;
        let consecutiveWins = 0;
        let jackpotBoxes = [];
        let gameStarted = false;

        // DOM Elements
        const gameBoard = document.getElementById('gameBoard');
        const playButton = document.getElementById('playButton');
        const coinOutButton = document.getElementById('coinOutButton');
        const minesSelect = document.getElementById('minesSelect');
        const randomButton = document.getElementById('randomButton');
        const transferButton = document.getElementById('transferButton');
        const coinDisplay = document.getElementById('coinDisplay');
        const scartinoScoreDisplay = document.getElementById('scartinoScore');
        const currentCoinsDisplay = document.getElementById('currentCoins');
        const messageArea = document.getElementById('messageArea');

        // Image Paths (Replace with your own paths)
        const MINE_IMAGE = '<img src="/img/mine.png" class="game-icon">';
        const COIN_IMAGE = '<img src="/img/dollar.png" class="game-icon">';
        const JACKPOT_IMAGE = '<img src="/img/logo.png" class="game-icon">';
        const SAFE_IMAGE = '<img src="/img/dollar.png" class="game-icon">';

        // Audio Elements
        const playSound = new Audio('/mp3 /play.mp3');
        const mineSound = new Audio('/mp3 /mines.mp3');
        const coinSound = new Audio('/mp3 /coin.mp3');
        const jackpotSound = new Audio('/mp3 /coin.mp3');
        const coinOutSound = new Audio('/mp3 /coinout.mp3');

        // Ensure sounds can play
        function enableSounds() {
          playSound.play().then(() => {}).catch(() => {});
          mineSound.play().then(() => {}).catch(() => {});
          coinSound.play().then(() => {}).catch(() => {});
          jackpotSound.play().then(() => {}).catch(() => {});
          coinOutSound.play().then(() => {}).catch(() => {});
          setTimeout(() => {
            playSound.pause();
            playSound.currentTime = 0;
            mineSound.pause();
            mineSound.currentTime = 0;
            coinSound.pause();
            coinSound.currentTime = 0;
            jackpotSound.pause();
            jackpotSound.currentTime = 0;
            coinOutSound.pause();
            coinOutSound.currentTime = 0;
          }, 100);
        }

        // Play sound with error handling
        function playAudio(audio) {
          try {
            audio.currentTime = 0;
            audio.play().catch(e => console.log("Audio play failed:", e));
          } catch (e) {
            console.log("Audio error:", e);
          }
        }

        // Initialize Game Board
        function initializeBoard() {
          gameBoard.innerHTML = '';
          jackpotBoxes = [];
          for (let i = 0; i < 25; i++) {
            const cell = document.createElement('div');
            cell.className = 'cell';

            const box = document.createElement('button');
            box.className = 'box bg-blue-800 rounded-md shadow-inner';
            box.innerHTML = '<div class="w-full h-full flex items-center justify-center"><div class="w-3 h-3 rounded-full bg-blue-600"></div></div>';
            box.addEventListener('click', () => {
              if (gameStarted) {
                handleBoxClick(i);
              } else {
                showMessage('Please start the game first');
              }
            });

            cell.appendChild(box);
            gameBoard.appendChild(cell);
          }
        }

        // Generate Random Mines
        function generateMines() {
          mines = [];
          while (mines.length < selectedMines) {
            const randomIndex = Math.floor(Math.random() * 25);
            if (!mines.includes(randomIndex)) {
              mines.push(randomIndex);
            }
          }
        }

        // Add Jackpot Boxes
        function addJackpotBoxes() {
          const unopenedBoxes = [];
          for (let i = 0; i < 25; i++) {
            if (!mines.includes(i) && !openedBoxes.includes(i)) {
              unopenedBoxes.push(i);
            }
          }

          if (unopenedBoxes.length > 0) {
            const numJackpots = Math.min(2, unopenedBoxes.length);
            for (let i = 0; i < numJackpots; i++) {
              const randomIndex = Math.floor(Math.random() * unopenedBoxes.length);
              jackpotBoxes.push(unopenedBoxes[randomIndex]);
              unopenedBoxes.splice(randomIndex, 1);
            }
          }
        }

        // Reveal All Boxes
        function revealAllBoxes() {
          for (let i = 0; i < 25; i++) {
            const box = gameBoard.children[i].firstChild;
            if (mines.includes(i)) {
              box.innerHTML = `<div class="w-full h-full flex items-center justify-center">${MINE_IMAGE}</div>`;
              box.classList.add('bg-red-500');
            } else if (jackpotBoxes.includes(i)) {
              box.innerHTML = `<div class="w-full h-full flex items-center justify-center">${JACKPOT_IMAGE}</div>`;
              box.classList.add('bg-purple-500');
            } else {
              box.innerHTML = `<div class="w-full h-full flex items-center justify-center">${SAFE_IMAGE}</div>`;
              box.classList.add('bg-green-800');
            }
          }
        }

        // Handle Box Click
        function handleBoxClick(index) {
          if (gameOver || openedBoxes.includes(index)) return;

          const box = gameBoard.children[index].firstChild;

          if (mines.includes(index)) {
            // Mine found - game over
            box.classList.add('mine-animation');
            playAudio(mineSound);
            setTimeout(() => {
              box.innerHTML = `<div class="w-full h-full flex items-center justify-center">${MINE_IMAGE}</div>`;
              box.classList.add('bg-red-500');
            }, 250);

            gameOver = true;
            consecutiveWins = 0;

            setTimeout(() => {
              revealAllBoxes();
              showMessage('Game Over! Mine hit!');
              resetGame();
            }, 500);
          } else {
            // Safe box
            if (jackpotBoxes.includes(index)) {
              // Jackpot box
              box.classList.add('jackpot-animation');
              playAudio(jackpotSound);
              setTimeout(() => {
                box.innerHTML = `<div class="w-full h-full flex items-center justify-center">${JACKPOT_IMAGE}</div>`;
                box.classList.add('bg-purple-500', 'jackpot');
              }, 250);

              currentCoins += 1;
              scartinoScore += 1;
              scartinoScoreDisplay.textContent = scartinoScore;
              jackpotBoxes = jackpotBoxes.filter(i => i !== index);
            } else {
              // Normal safe box
              box.classList.add('coin-animation');
              playAudio(coinSound);
              setTimeout(() => {
                box.innerHTML = `<div class="w-full h-full flex items-center justify-center">${SAFE_IMAGE}</div>`;
                box.classList.add('bg-green-800');
              }, 250);
              currentCoins++;
            }

            openedBoxes.push(index);
            currentCoinsDisplay.textContent = currentCoins;

            // Check for consecutive wins
            if (selectedMines >= 5) {
              consecutiveWins++;
              if (consecutiveWins >= 3 && jackpotBoxes.length === 0) {
                addJackpotBoxes();
                consecutiveWins = 0;
              }
            }

            // Check if all safe boxes are opened
            if (openedBoxes.length === 25 - selectedMines) {
              setTimeout(() => {
                revealAllBoxes();
                showMessage('All mines cleared!');
                playAudio(coinOutSound); // Play coin out sound when all cleared
                handleCoinOut();
              }, 500);
            }
          }
        }

        // Show Message
        function showMessage(message) {
          const messageElement = messageArea.querySelector('.message-text') || messageArea;
          messageElement.textContent = message;
        }

        // Handle Play Button Click
        function handlePlayClick() {
          selectedMines = parseInt(minesSelect.value);

          if (selectedMines < 1 || selectedMines > 20) {
            showMessage('Please select 1-20 mines first');
            return;
          }

          playAudio(playSound);
          initializeBoard();
          generateMines();
          playButton.classList.add('hidden');
          coinOutButton.classList.remove('hidden');
          randomButton.disabled = false;
          gameOver = false;
          gameStarted = true;
          currentCoins = 0;
          currentCoinsDisplay.textContent = currentCoins;
          openedBoxes = [];
          consecutiveWins = 0;
          showMessage('Game started!');
        }

        // Handle Coin Out
        function handleCoinOut() {
          playAudio(coinOutSound); // Play coin out sound
          totalCoins += currentCoins;
          coinDisplay.textContent = totalCoins;
          showMessage(`Earned ${currentCoins} coins`);
          setTimeout(() => {
            revealAllBoxes();
            resetGame();
          }, 500);
        }

        // Reset Game
        function resetGame() {
          playButton.classList.remove('hidden');
          coinOutButton.classList.add('hidden');
          randomButton.disabled = true;
          gameOver = true;
          gameStarted = false;
          setTimeout(initializeBoard, 1000);
        }

        // Handle Random Button
        function handleRandomClick() {
          if (!gameStarted) return;

          const unopenedBoxes = [];
          for (let i = 0; i < 25; i++) {
            if (!openedBoxes.includes(i)) {
              unopenedBoxes.push(i);
            }
          }

          if (unopenedBoxes.length > 0) {
            const randomIndex = Math.floor(Math.random() * unopenedBoxes.length);
            handleBoxClick(unopenedBoxes[randomIndex]);
          }
        }

        // Handle Transfer Button
        function handleTransferClick() {
          showMessage('Transfer functionality would go here');
          // In a real app, this would transfer coins to main wallet
        }

        // Initialize sounds
        enableSounds();

        // Event Listeners
        playButton.addEventListener('click', handlePlayClick);
        coinOutButton.addEventListener('click', handleCoinOut);
        randomButton.addEventListener('click', handleRandomClick);
        transferButton.addEventListener('click', handleTransferClick);

        // Initialize Game
        initializeBoard();