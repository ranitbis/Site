const mainLogo = document.getElementById('mainLogo');
const depositCounter = document.getElementById('depositCounter');
const remainingTouches = document.getElementById('remainingTouches');
const scartinoAmount = document.getElementById('scartinoAmount');
const boostButton = document.getElementById('boostButton');
const messageContainer = document.getElementById('messageContainer');
const accumulatedCoins = document.getElementById('accumulatedCoins');
const thankYouButton = document.getElementById('thankYouButton');
const vipLevelElement = document.getElementById('vipLevel');
const progressText = document.getElementById('progressText');
const progressBar = document.getElementById('progressBar');
const collectRewardBtn = document.getElementById('collectReward');
const rewardPopup = document.getElementById('rewardPopup');
const closeRewardPopup = document.getElementById('closeRewardPopup');
const rewardVipLevel = document.getElementById('rewardVipLevel');
const rewardAmount = document.getElementById('rewardAmount');

let counter = 0;
let timeSpentOutside = 0;
const maxTouches = 1000;
let energyInterval;
let autoDepositInterval;
let lastTimestamp = parseInt(localStorage.getItem('lastTimestamp')) || Date.now();

// VIP সিস্টেম কনফিগারেশন
const vipRequirements = [
    0, // VIP 0 (কোন requirement নেই)
    100, // VIP 1
    300, // VIP 2
    600, // VIP 3
    1000, // VIP 4
    1500, // VIP 5
    2100, // VIP 6
    2800, // VIP 7
    3600, // VIP 8
    4500, // VIP 9
    5500, // VIP 10
    7000, // VIP 11
    10000 // VIP 12
];

const vipRewards = [
    0, // VIP 0 (কোন reward নেই)
    10, // VIP 1
    30, // VIP 2
    60, // VIP 3
    100, // VIP 4
    150, // VIP 5
    210, // VIP 6
    280, // VIP 7
    360, // VIP 8
    450, // VIP 9
    550, // VIP 10
    700, // VIP 11
    1000 // VIP 12
];

// VIP প্রোগ্রেস আপডেট ফাংশন
function updateVipProgress() {
  const scartinoCoins = parseFloat(scartinoAmount.textContent);
  let currentVip = 0;

  // বর্তমান VIP লেভেল নির্ধারণ
  for (let i = 1; i <= 12; i++) {
    if (scartinoCoins >= vipRequirements[i]) {
      currentVip = i;
    } else {
      break;
    }
  }

  // UI আপডেট
  vipLevelElement.textContent = currentVip;

  // পরবর্তী VIP লেভেলের জন্য প্রোগ্রেস ক্যালকুলেশন
  let nextVipLevel = currentVip < 12 ? currentVip + 1 : 12;
  let progress = 0;

  if (currentVip < 12) {
    const currentRequirement = vipRequirements[currentVip];
    const nextRequirement = vipRequirements[nextVipLevel];
    progress = ((scartinoCoins - currentRequirement) / (nextRequirement - currentRequirement)) * 100;
    progressText.textContent = `${Math.floor(scartinoCoins - currentRequirement)}/${nextRequirement - currentRequirement}`;
  } else {
    progress = 100;
    progressText.textContent = 'MAX';
  }

  progressBar.style.width = `${progress}%`;
  progressBar.style.backgroundColor = getVipColor(currentVip);

  // Collect Reward বাটন সক্রিয়/নিষ্ক্রিয় করো
  if (currentVip < 12 && scartinoCoins >= vipRequirements[currentVip + 1]) {
    collectRewardBtn.classList.add('active');
    collectRewardBtn.style.cursor = 'pointer';
  } else {
    collectRewardBtn.classList.remove('active');
    collectRewardBtn.style.cursor = 'default';
  }
}

// VIP লেভেল অনুযায়ী রঙ নির্ধারণ
function getVipColor(vipLevel) {
  const colors = [
        '#CD7F32', // ব্রোঞ্জ
        '#C0C0C0', // সিলভার
        '#FFD700', // গোল্ড
        '#E5E4E2', // প্লাটিনাম
        '#B9F2FF', // ডায়মন্ড
        '#FF0000', // VIP 6-12 লাল গ্রেডিয়েন্ট
        '#FF4500',
        '#FF6347',
        '#FF7F50',
        '#FF8C00',
        '#FFA500',
        '#FFD700',
        '#FFFF00'
    ];
  return colors[Math.min(vipLevel, colors.length - 1)];
}

// Scartino Amount আপডেট করার ফাংশন
function updateScartinoAmount(newAmount) {
  scartinoAmount.textContent = newAmount.toFixed(6);
  localStorage.setItem('exchangedScartinoAmount', newAmount.toFixed(6));
  updateVipProgress();
}

// Energy touch click event
mainLogo.addEventListener('click', () => {
  let currentEnergy = parseInt(remainingTouches.textContent);
  if (currentEnergy > 0) {
    counter++;
    depositCounter.textContent = counter;
    remainingTouches.textContent = currentEnergy - 1;

    localStorage.setItem('depositCounter', counter);
    localStorage.setItem('remainingTouches', remainingTouches.textContent);

    mainLogo.classList.add('shake');

    const plusOne = document.createElement('div');
    plusOne.classList.add('plus-one');
    plusOne.textContent = '+1';
    mainLogo.parentElement.appendChild(plusOne);

    setTimeout(() => {
      mainLogo.classList.remove('shake');
      plusOne.remove();
    }, 1000);
  }

  if (!energyInterval) {
    energyInterval = setInterval(() => {
      let currentEnergy = parseInt(remainingTouches.textContent);
      if (currentEnergy < maxTouches) {
        remainingTouches.textContent = currentEnergy + 1;
        localStorage.setItem('remainingTouches', remainingTouches.textContent);
      }
    }, 1000);
  }
});

// Automatically store 1 coin in the deposit counter every 2.5 seconds
autoDepositInterval = setInterval(() => {
  counter++;
  depositCounter.textContent = counter;
  localStorage.setItem('depositCounter', counter);
}, 2500);

// Boost functionality to restore energy to max
boostButton.addEventListener('click', () => {
  remainingTouches.textContent = maxTouches;
  localStorage.setItem('remainingTouches', maxTouches);
});

// Collect reward বাটন ক্লিক ইভেন্ট
collectRewardBtn.addEventListener('click', function() {
  if (!collectRewardBtn.classList.contains('active')) return;

  const currentVip = parseInt(vipLevelElement.textContent);
  const nextVipLevel = currentVip + 1;
  const scartinoCoins = parseFloat(scartinoAmount.textContent);

  if (nextVipLevel <= 12 && scartinoCoins >= vipRequirements[nextVipLevel]) {
    rewardVipLevel.textContent = nextVipLevel;
    rewardAmount.textContent = vipRewards[nextVipLevel];
    rewardPopup.style.display = 'block';
  }
});

// Reward পপআপ বন্ধ করুন এবং কোয়েন যোগ করুন
closeRewardPopup.addEventListener('click', function() {
  const currentVip = parseInt(vipLevelElement.textContent);
  const nextVipLevel = currentVip + 1;
  const reward = vipRewards[nextVipLevel];
  const currentAmount = parseFloat(scartinoAmount.textContent);
  const newAmount = currentAmount + reward;

  updateScartinoAmount(newAmount);
  rewardPopup.style.display = 'none';
});

// Handle focus event to calculate time spent outside
window.addEventListener('focus', () => {
  const currentTimestamp = Date.now();
  timeSpentOutside = currentTimestamp - lastTimestamp;
  lastTimestamp = currentTimestamp;

  const elapsedCoins = Math.floor(timeSpentOutside / 2500);

  if (elapsedCoins > 0) {
    accumulatedCoins.textContent = elapsedCoins;
    messageContainer.style.display = 'flex';
  }
});

// "Thank you" button
thankYouButton.addEventListener('click', () => {
  messageContainer.style.display = 'none';
  let accumulated = parseInt(accumulatedCoins.textContent);
  counter += accumulated;
  depositCounter.textContent = counter;
  localStorage.setItem('depositCounter', counter);
  accumulatedCoins.textContent = 0;
  clearInterval(autoDepositInterval);
  autoDepositInterval = setInterval(() => {
    counter++;
    depositCounter.textContent = counter;
    localStorage.setItem('depositCounter', counter);
  }, 2500);
});

// Save Timestamp When Leaving  
window.addEventListener('beforeunload', () => {
  localStorage.setItem('lastTimestamp', Date.now());
  clearInterval(energyInterval);
  clearInterval(autoDepositInterval);
});

window.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden') {
    localStorage.setItem('lastTimestamp', Date.now());
  }
});

// প্রাথমিক ডেটা লোড করুন
if (localStorage.getItem('depositCounter')) {
  counter = parseInt(localStorage.getItem('depositCounter'));
  depositCounter.textContent = counter;
}

if (localStorage.getItem('remainingTouches')) {
  remainingTouches.textContent = localStorage.getItem('remainingTouches');
}

const exchangedScartino = localStorage.getItem('exchangedScartinoAmount') || '0.000000';
scartinoAmount.textContent = exchangedScartino;

// প্রাথমিক VIP প্রোগ্রেস আপডেট
updateVipProgress();