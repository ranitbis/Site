
const CACHE_NAME = 'scartino-mining-cache-v1';
const urlsToCache = ['/html/walletpage.htm', '/html/bankqr.html', '/html/minimg.html', '/html/homepage.html', '/html/exchenge.html', '/html/bankfrom.html', '/html/game.htm', '/html/mines.html', '/html/shooter.html', '/html/auth.html', '/html/game.html', '/img/rocket.png', '/img/salary.png', '/img/facebook.png', '/img/renewable-energy.png', '/img/mining.png', '/img/youtube.png', '/img/20241221_112646.jpg', '/img/logo.png', '/img/telegram.png', '/img/dollar.png', '/img/game-console.png', '/img/exchnage.png', '/img/d28bc7c855f8e461955eca5fd9d68aae.jpg', '/img/mine.png', '/img/gamebg.jpg'];

self.addEventListener('install', function(event) {
  event.waitUntil(
    caches.open(CACHE_NAME).then(function(cache) {
      return cache.addAll(urlsToCache);
    })
  );
});

self.addEventListener('fetch', function(event) {
  event.respondWith(
    caches.match(event.request).then(function(response) {
      return response || fetch(event.request);
    })
  );
});
